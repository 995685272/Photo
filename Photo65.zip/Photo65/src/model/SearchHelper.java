package model;

import java.util.ArrayList;

public class SearchHelper {
    public static ArrayList<Album> getAlbum = new ArrayList<Album>();
    public static ArrayList<Photo> getPhoto = new ArrayList<Photo>();
}
